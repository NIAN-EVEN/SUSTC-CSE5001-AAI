from sklearn.externals import joblib
import pandas as pd

def getData(trainfile, testfile):
    '''从文件中获取数据'''
    train = pd.read_csv(trainfile)
    Xt = pd.read_csv(testfile)
    col = [x for x in train.columns if x != 'Category']
    X = train[col]
    y = train['Category']
    return X, y, Xt
    # return np.array(X), np.array(y), np.array(Xt)

def setPrediction(filename, result):
    '''存储预测结果'''
    filename += ".csv"
    with open(filename, 'x') as f:
        f.write("id,category\n")
        for idx, category in enumerate(result):
            f.write(str(idx+1) + ',' + str(category) + '\n')


if __name__ == "__main__":
    # 文件路径
    trainfile = "train.csv"
    testfile = "test.csv"
    # 获取数据
    X, y, Xt = getData(trainfile, testfile)
    # 加载模型
    clf = joblib.load("trained_model")
    # 数据预测
    result = clf.predict(Xt)
    resultfile = "11849058-submission"
    setPrediction(resultfile, result)
