1. 文档结构：
./
 |-readme.txt
 |-report11849058.pdf
 |-codes/
		|-classifier-11849058.py # 主程序，进行了(1)文件读入(2)模型读入(3)结果预测(4)存储文件四个操作
		|-trained_model # 训练好的模型
		|-ensembleLearning.py # 训练模型程序，进行了(1)文件读入(2)模型训练(3)结果预测(4)存储模型(5)存储预测结果五个操作
		|-searchAndVal.py # 网格搜索调参部分
		|-visualization.py # 数据可视化分析部分
		|-train.csv # kaggle上下载的训练数据集
		|-test.csv # kaggle上下载的测试数据集
 
 
2. 程序用python3.6 实现，使用了(1)sklearn (2)numpy (3)pandas三个包，程序目录文件夹已经包含训练数据集和测试数据集
   在codes目录下运行程序，执行下列指令即可生成名称为"11849058-submission.csv"的合法预测文件
	python classifier-11849058.py
	（注：此处第二次执行时若未删除上一次产生的csv文件，程序会因为文件已存在而报错）