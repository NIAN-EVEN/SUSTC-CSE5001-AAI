1. 代码结构：
./
 |-readme.txt
 |-sklearn_svm.py # 主程序，进行了(1)文件读入(2)数据标准化处理(3)特征扩充(4)训练预测(5)结果输出五个操作
 |-11849058-submission.csv # 程序输出
 |-train.csv # kaggle上下载的训练数据集
 |-test.csv # kaggle上下载的测试数据集
 
2. 程序用python3.6 实现，使用了(1)sklearn (2)numpy两个包，程序目录文件夹已经包含训练数据集和测试数据集
   运行程序需要执行下列指令即可生成名称为"11849058-submission.csv"的合法预测文件（注：此处第二次执行时若为删除上一次产生的csv文件，程序会因为文件已存在而报错）
	python sklearn_svm.py

3. 本文件只包含最终成果，即可利用训练数据训练SVM模型并给出预测结果的python程序文件，具体过程会在作业PRE环节展示