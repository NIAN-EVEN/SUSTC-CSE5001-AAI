from sklearn import svm
from sklearn.preprocessing import StandardScaler as stdScaler
from sklearn.preprocessing import MinMaxScaler as maxminScaler
from sklearn.preprocessing import RobustScaler as rbScaler
from sklearn.preprocessing import QuantileTransformer as qtScaler
from sklearn.decomposition import PCA
import numpy as np
import time, os

parameter = {'C': 214.5,
              'gamma': 4,
              'cache_size': 500}

def getData(trainFile, testFile = None):
    '''从文件中读取训练数据和测试数据
       训练数据存储到train中，并划分成(X, y)
       测试数据存储到test中'''
    X = []
    y = []
    test = []
    print("get data...")
    with open(trainFile, "r") as f:
        for line in f.readlines()[1:]:
            train = list(map(float, line.strip().split(",")))
            X.append(train[:-1])
            y.append(int(train[-1]))
    if testFile == None:
        return np.array(X), np.array(y)
    else:
        with open(testFile, "r") as f:
            for line in f.readlines()[1:]:
                test.append(list(map(float, line.strip().split(","))))
        return np.array(X), np.array(y), np.array(test)

def setData(result, file):
    '''对测试集合的训练数据输出到文件中
        result表示预测结果，file代表filename后缀，存储当前参数'''
    print("set data...")
    filename = file + ".csv"
    with open(filename, 'x') as f:
        f.write('id,category\n')
        for idx, category in enumerate(result):
            f.write(str(idx+1) + "," + str(category) +"\n")

def standardlization(X, *other):
    print('STD transform...')
    scl = stdScaler().fit(X)
    others = []
    others.append(scl.transform(X))
    for o in other:
        others.append(scl.transform(o))
    if len(others) > 1:
        return others
    else:
        return  others[0]

def MaxMinStandardlization(X, *other):
    print('max min transform...')
    scl = maxminScaler().fit(X)
    others = []
    others.append(scl.transform(X))
    for o in other:
        others.append(scl.transform(o))
    if len(others) > 1:
        return others
    else:
        return  others[0]

def robustStandardlization(X, *other):
    print('robust transform...')
    scl = rbScaler().fit(X)
    others = []
    others.append(scl.transform(X))
    for o in other:
        others.append(scl.transform(o))
    if len(others) > 1:
        return others
    else:
        return others[0]

def qtStandardlization(X, *other):
    print('qt transform...')
    scl = qtScaler().fit(X)
    others = []
    others.append(scl.transform(X))
    for o in other:
        others.append(scl.transform(o))
    if len(others) > 1:
        return others
    else:
        return others[0]


def PCAtransform(X, test):
    '''PCA methods'''
    print('PAC transform...')
    # sklearn pca
    pca = PCA(n_components='mle', svd_solver='full')
    pca.fit(X)
    return pca.transform(X), pca.transform(test)

def SVC_predict(X, y, parameter, test):
    result = []
    print("sklearn svm...")
    # clf = svm.SVC()
    clf = svm.SVC(C=parameter['C'],
                  gamma=parameter['gamma'],
                  cache_size=parameter['cache_size'])
    clf.fit(X, y)
    result.extend(list(clf.predict(test)))
    return result

def combine4(X0, X1, X2, X3, test0, test1, test2, test3, PCA = False):
    if PCA == False:
        return np.hstack((X0, X1, X2, X3)), np.hstack((test0, test1, test2, test3))
    else:
        return PCAtransform(np.hstack((X0, X1, X2, X3)), np.hstack((test0, test1, test2, test3)))

def deleteLOF(X, y):
    data = np.array([[4.9800e+05, 2.7130e+04, 1.3400e+02, 1.3155e+04, 5.5500e+02, -4.2735e+04],
                     [1.1425e+04, 8.0789e+03, 2.3000e+01, 5.8200e+02, 1.2800e+02, -3.4000e+06],
                     [6.7300e+05, 2.9567e+04, 1.3900e+02, 1.7346e+04, 6.6300e+02, -3.6000e+05],
                     [3.5446e+04, 1.1567e+04, 2.8000e+01, 1.5810e+03, 2.3500e+02, 5.6000e+04],
                     [2.8881e+04, 1.1906e+04, 9.7000e+01, 1.4690e+03, 2.1800e+02, -2.2300e+06],
                     [1.5700e+06, 4.3916e+04, 1.6300e+02, 3.7041e+04, 8.7300e+02, -9.6450e+04],
                     [4.3300e+05, 2.1291e+04, 3.0700e+02, 1.1269e+04, 4.0000e+02, -5.8766e+04],
                     [2.1218e+04, 8.1976e+03, 1.3000e+01, 1.2520e+03, 1.4400e+02, -3.7275e+04],
                     [1.1200e+05, 1.1648e+04, 4.8000e+01, 4.9050e+03, 2.3400e+02, 7.5300e+04],
                     [1.8600e+06, 3.8407e+04, 1.9900e+02, 4.0370e+04, 8.0800e+02, -1.9959e+04],
                     [1.4300e+05, 1.5134e+04, 5.2000e+01, 5.8440e+03, 3.1600e+02, 1.3600e+05],
                     [2.5600e+05, 2.2962e+04, 9.1000e+01, 8.8700e+03, 5.4100e+02, 2.2900e+04],
                     [4.8354e+04, 1.2021e+04, 3.1000e+01, 1.4130e+03, 1.6500e+02, 4.6600e+04],
                     [4.7100e+05, 2.5331e+04, 5.1000e+01, 1.5505e+04, 4.8300e+02, 4.9601e+04],
                     [2.3500e+06, 5.0895e+04, 3.0100e+02, 3.8971e+04, 9.6300e+02, -2.5389e+04],
                     [1.3300e+05, 1.5848e+04, 5.8000e+01, 5.2160e+03, 3.1600e+02, -5.5076e+04],
                     [3.8700e+05, 2.3661e+04, 1.0600e+02, 9.4120e+03, 4.6600e+02, -1.3700e+05]
                     ])
    rsl = np.array([0, 0, 0, 3, 0, 0, 0, 0, 4, 0, 4, 4, 3, 4, 0, 0, 0])
    X_new = []
    y_new = []
    for d0, r0 in zip(X, y):
        has = False
        for d1, r1 in zip(data, rsl):
            if (d0==d1).all() and r0==r1:
                has = True
                break
        if has == False:
            X_new.append(d0)
            y_new.append(r0)
    return np.array(X_new), np.array(y_new)


if __name__ == "__main__":
    X, y, test = getData('train.csv', 'test.csv')
    X, y = deleteLOF(X, y)
    # 标准化
    X0, test0 = standardlization(X, test)
    X1, test1 = MaxMinStandardlization(X, test)
    X2, test2 = robustStandardlization(X, test)
    X3, test3 = qtStandardlization(X, test)
    X, test = combine4(X0, X1, X2, X3, test0, test1, test2, test3, PCA=True)
    result = SVC_predict(X, y, parameter, test)
    setData(result, '11849058-submission')